const axios = require('axios');

const clc = require('cli-color');

const moment = require('moment-timezone');

/**

 * Melakukan pengecekan mutasi QRIS ke endpoint kasir.orderkuota.com.

 * Fungsi ini memerlukan environment variables berikut untuk diatur:

 * - ORDERKUOTA_MERCHANT_ID: ID Merchant untuk parameter URL.

 * - MERCHANT_KEY: Kunci merchant untuk header 'referer'.

 * - APIKEY_ORKUT: Kunci API untuk header 'referer'.

 */

const checkQRIS = async () => {

    // Pastikan semua environment variable yang dibutuhkan telah diatur

    if (!process.env.MERCHANT_KEY || !process.env.APIKEY_ORKUT) {

        console.log(clc.red.bold("[ ERROR ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.yellow(` Harap pastikan environment variable MERCHANT_KEY, dan APIKEY_ORKUT sudah diatur.`));

        return false;

    }

    const KASIR_HOST = 'kasir.orderkuota.com';

    const url = `https://${KASIR_HOST}/qris/curl/mutasi.php`;

    // Parameter yang akan dikirim sebagai query string di URL

    const params = {

        timestamp: Date.now(),

        merchant: process.env.MERCHANT_KEY

    };

    // Header kustom yang diperlukan oleh API

    const headers = {

        'Host': KASIR_HOST,

        'accept': 'application/json',

        'referer': `https://kasir.orderkuota.com/qris/?id=${process.env.MERCHANT_KEY}&key=${process.env.APIKEY_ORKUT}`,

        'user-agent': 'WebView',

        'x-requested-with': 'com.orderkuota.app'

    };

    try {

        console.log(clc.greenBright("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.white(` Mengirim permintaan cek mutasi ke ${url}`));

        // Mengirim permintaan GET dengan URL, parameter, dan header yang telah dikonfigurasi

        const response = await axios.get(url, {

            params: params,

            headers: headers

        });

        

        console.log(clc.greenBright.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.white(` Berhasil mendapatkan data mutasi.`));

        

        // Mengembalikan data dari respons

        return response.data;

    } catch (err) {

        // Penanganan error yang lebih detail untuk debugging

        console.log(clc.red.bold("[ ERROR ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Gagal saat cek transaksi: ${err.message}`));

        

        // Jika error berasal dari respons server (misal: 401, 403, 500), tampilkan detailnya

        if (err.response) {

            console.log(clc.yellow(` -> Status Code: ${err.response.status}`));

            console.log(clc.yellow(` -> Response Data: ${JSON.stringify(err.response.data)}`));

        }

        

        return false;

    }

};

module.exports = checkQRIS;