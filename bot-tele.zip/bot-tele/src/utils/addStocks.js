const stockModels = require('../database/models/stockModels');
const moment = require('moment-timezone');
const clc = require('cli-color')

const addStocks = async (text, code) => {
  try {
    // Pisahkan teks berdasarkan newline (\n)
    const products = text.split("\n").map(product => product.trim()).filter(product => product);

    for (const product of products) {
      const newStock = new stockModels({
        codeVariant: code,
        dataStock: product
      });

      await newStock.save();
    }

    console.log(clc.green.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Stocks added successfully`));
    return;
  } catch (err) {
    console.log(clc.red.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Error add stock : ${err.message}`));
  }
};

module.exports = addStocks;