const productsModels = require("../database/models/productsModels");
const clc = require('cli-color');
const moment = require('moment-timezone');
const { getAddProductIs, setAddProductIs } = require("../command/privateCommand/addProduct");
const { getAddProductVariantsIs, setAddProductVarinatsIs } = require("../command/privateCommand/addProductVariant");
const productsVariantModels = require("../database/models/productsVariantModels");

const middleware = async (ctx, next) => {
    try {
        const userMessage = ctx.message.text;

        if (userMessage.includes("Deskripsi Product :") && userMessage.includes("Name Product :")) {
            const nameMatch = userMessage.match(/Name Product\s*:\s*(.+)/);
            const deskripsiMatch = userMessage.match(/Deskripsi Product\s*:\s*(.+)/);

            const nameProduct = nameMatch ? nameMatch[1].trim() : null;
            const deskripsiProduct = deskripsiMatch ? deskripsiMatch[1].trim() : null;

            if (nameProduct && deskripsiProduct && getAddProductIs()) {
                const getProduct = await productsModels.find()

                const newProduct = new productsModels({
                    name: nameProduct,
                    description: deskripsiProduct,
                    code: getProduct.length + 1
                })

                await newProduct.save()
                    .then(async () => {
                        setAddProductIs(false)
                        console.log(clc.green.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Successfully add new product ${nameProduct}`));
                        ctx.replyWithMarkdown(`*Success add new product ${nameProduct}✅*`)
                    })
            }
        }

        if (userMessage.includes("Name Variant :") && userMessage.includes("Number Product :") && userMessage.includes("Code Variant :") && userMessage.includes("Price (Hanya Angka!) :") && userMessage.includes("Deskripsi Variant :")) {
            const nameMatch = userMessage.match(/Name Variant\s*:\s*(.+)/);
            const codeMatch = userMessage.match(/Code Variant\s*:\s*(.+)/);
            const priceMatch = userMessage.match(/Price \(Hanya Angka!\)\s*:\s*(\d+)/);
            const NumberListMatch = userMessage.match(/Number Product\s*:\s*(\d+)/);
            const deskripsiMatch = userMessage.match(/Deskripsi Variant\s*:\s*(.+)/);
            const textReply = ctx.message?.reply_to_message?.text ?? ""

            if (textReply == "") {
                return ctx.reply("*⚠️ HARAP ISI KETERANGAN VARIANT DENGAN CARA DI REPLY! ⚠️*", {
                    parse_mode: "Markdown"
                })
            }

            if (nameMatch && codeMatch && priceMatch && deskripsiMatch && NumberListMatch && getAddProductVariantsIs()) {
                const nameVariant = nameMatch[1].trim();
                const codeVariant = codeMatch[1].trim();
                const price = priceMatch[1].trim();
                const deskripsiVariant = deskripsiMatch[1].trim();
                const NumberListProduct = NumberListMatch[1].trim();

                const checkProduct = await productsModels.findOne({ code: NumberListProduct });

                if (!checkProduct) {
                    return ctx.reply("*⚠️ MASUKKAN NOMOR LIST PRODUCT YANG TERSEDIA! ⚠️*", {
                        parse_mode: "Markdown"
                    })
                }

                const newProductVariants = new productsVariantModels({
                    name: nameVariant,
                    code: NumberListProduct,
                    codeVariant: codeVariant,
                    descriptionVariant: deskripsiVariant,
                    price: price,
                    keteranganVariant: textReply
                })

                newProductVariants.save()
                    .then(async () => {
                        setAddProductVarinatsIs(false)
                        console.log(clc.green.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Successfully add new product variants ${nameVariant}`));
                        ctx.replyWithMarkdown(`*Success add new product ${nameVariant}✅*`)
                    })
            }
        }

        return next();
    } catch (err) {
        ctx.reply("*⚠️SOMETHING ERROR IN MIDDLEWARE⚠️*", {
            parse_mode: "Markdown",
        })
        console.log(clc.red.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Something error in file middleware.js  ${err.message}`));
        return next();
    }
};

module.exports = middleware;
