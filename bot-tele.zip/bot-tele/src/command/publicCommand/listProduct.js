const clc = require('cli-color');
const moment = require('moment-timezone');
const productModels = require('../../database/models/productsModels');
const { Input } = require('telegraf');

const listProduct = async (ctx) => {
    try {
        const from = ctx.from
        const allProduct = await productModels.find()
        
        if (allProduct.length > 0) {
            let productMessage = "╭──────〔 *LIST PRODUCT* 〕─ "
            const array = [
                ["LIST PRODUCT📦"],
            ];

            let i = 0
            for (const data of allProduct) {
                i++
                productMessage += `\n*┊ [ *${i}* ] ${data.name.toUpperCase()}*`
            }
            productMessage += "\n╰─────────────────╯"

            const addButtonArray = async (start, end) => {
                let newArray = [];

                for (let i = start; i <= end; i++) {
                    const emojiResult = i

                    newArray.push(emojiResult.toString());

                    if (newArray.length >= 6) {
                        array.push(newArray);
                        newArray = [];
                    }
                }

                if (newArray.length > 0) {
                    array.push(newArray);
                }
            };


            await addButtonArray(1, allProduct.length)
            array.push(["HOW TO ORDER❓"],
                ["BEST PRODUCT💰", "TOP BUYER👑"])

            await ctx.telegram.sendPhoto(from.id, Input.fromLocalFile('src/img/poster.png'), {
                caption: productMessage,
                reply_markup: {
                    keyboard: array,
                    resize_keyboard: true
                },
                parse_mode: "Markdown"
            })
        } else {
            const message = "*⚠️ BELUM ADA PRODUCT ⚠️*"

            await ctx.telegram.sendPhoto(from.id, Input.fromLocalFile('src/img/poster.png'), {
                caption: message,
                parse_mode: "Markdown",
                disable_web_page_preview: "true",
            })
        }

    } catch (err) {
        ctx.reply("*⚠️SOMETHING ERROR TO BACK⚠️*", {
            parse_mode: "Markdown",
        })
        console.log(clc.red.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Something error in file command/listProduct.js  ${err.message}`));
    }
}

module.exports = listProduct