const caraAddProduct = require("./helpCommand/caraAddProduct");
const caraAddStock = require("./helpCommand/caraAddStock");
const caraAddVariant = require("./helpCommand/caraAddVariant");
const caraBroadcast = require("./helpCommand/caraBroadcast");
const caraDelProduct = require("./helpCommand/caraDelProduct");
const caraDelStock = require("./helpCommand/caraDelStock");
const caraDelVariant = require("./helpCommand/caraDelVariant");
const caraSetHarga = require("./helpCommand/caraSetHarga");
const { addProduct } = require("./privateCommand/addProduct");
const { addProductVariants } = require("./privateCommand/addProductVariant");
const addStock = require("./privateCommand/addStock");
const adminPanelCommand = require("./privateCommand/adminPanel");
const broadcastCommand = require("./privateCommand/broadcast");
const delProductVariant = require("./privateCommand/delProduct");
const delProduct = require("./privateCommand/delProductVariant");
const delStock = require("./privateCommand/delStock");
const setHarga = require("./privateCommand/setHarga");
const helpCommand = require("./publicCommand/help");
const listProduct = require("./publicCommand/listProduct");
const startCommand = require("./start");

module.exports = {
    startCommand,
    addStock,
    listProduct,
    addProduct,
    broadcastCommand,
    addProductVariants,
    adminPanelCommand,
    helpCommand,
    delStock,
    delProduct,
    delProductVariant,
    setHarga,
    caraSetHarga,
    caraAddProduct,
    caraDelProduct,
    caraDelVariant,
    caraBroadcast,
    caraAddStock,
    caraDelStock,
    caraAddVariant
}