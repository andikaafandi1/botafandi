const moment = require('moment-timezone');
const clc = require('cli-color');
const broadcastModels = require('../../database/models/broadcastModels');

const broadcastCommand = async (ctx) => {
    try {

        if (process.env.WHITELIST_ID != ctx.from.id) {
            return;
        }

        const allDataBroadcast = await broadcastModels.find()
        const fullMessage = ctx.message.text;
        const messageWithoutCommand = fullMessage.replace('/broadcast', '').trim();
        const messageToBroadcast = `*[ 📢 BROADCAST 📢 ]*\n\n${messageWithoutCommand}`

        for (const data of allDataBroadcast) {
            await ctx.telegram.sendMessage(data.idTelegram, messageToBroadcast, {
                parse_mode: "Markdown"
            })
        }

        await ctx.replyWithMarkdown("*SUCCESSFULL SENDING MESSAGE BROADCAST✅*")
    } catch (err) {
        ctx.reply("*⚠️SOMETHING ERROR IN COMMAND BROADCAST⚠️*", {
            parse_mode: "Markdown",
        })
        console.log(clc.red.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Something error in file command/privateCommand/broadcast.js :  ${err.message}`));
    }
}

module.exports = broadcastCommand