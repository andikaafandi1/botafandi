const moment = require('moment-timezone');
const clc = require('cli-color');
const productsVariantModels = require('../../database/models/productsVariantModels');
const stockModels = require('../../database/models/stockModels');

const addStock = async (ctx) => {
    try {
        const idTelegram = ctx.from.id
        if (process.env.WHITELIST_ID == idTelegram) {
            const input = ctx.message.text.split(" ");
            const textReply = ctx.message?.reply_to_message?.text ?? ""
            const checkCode = await productsVariantModels.findOne({ codeVariant: input[1] });

            if (!checkCode) {
                return ctx.reply("*⚠️ CODE VARIANT PRODUCT TIDAK DI TEMUKAN ⚠️*", {
                    parse_mode: "Markdown"
                })
            } else if (textReply == "") {
                return ctx.reply("*⚠️ HARAP REPLY TEXT STOCK NYA AGAR BISA DI TAMBAHKAN ⚠️*", {
                    parse_mode: "Markdown"
                })
            }

            let i = 0
            await textReply.split("\n").forEach(async (data) => {
                i++
                const addStock = new stockModels({
                    codeVariant: input[1],
                    dataStock: data
                });

                await addStock.save()
            })

            ctx.reply(`*✅ BERHASIL MENAMBAHKAN STOCK | TOTAL STOCK YANG DI TAMBAHKAN : ${i} ✅*`, {
                parse_mode: "Markdown"
            })

        }
    } catch (err) {
        ctx.reply("*⚠️SOMETHING ERROR IN COMMAND ADDSTOCK⚠️*", {
            parse_mode: "Markdown",
        })
        console.log(clc.red.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Something error in file command/privateCommand/addStock.js  ${err.message}`));
    }
}

module.exports = addStock