const clc = require('cli-color');
const moment = require('moment-timezone');
const productsVariantModels = require('../../database/models/productsVariantModels');

const delProductVariant = async (ctx) => {
    try {

        if (ctx.from.id != process.env.WHITELIST_ID) {
            return
        }

        const code = ctx.message.text.split(" ")
        const cekProduk = await productsVariantModels.findOne({ codeVariant: code[1] })

        if (!cekProduk) {
            await ctx.reply("*❗Code yang kamu masukkan tidak di temukan*", {
                parse_mode: "Markdown"
            });
            return
        }

        await productsVariantModels.deleteOne({ codeVariant: code[1] })
        .then(async () => {
            await ctx.reply(`*Berhasil menghapus product variant dengan code ${code[1].toUpperCase()}✅*`, {
                parse_mode: "Markdown"
            });
        })
    } catch (err) {
        ctx.reply("*⚠️SOMETHING ERROR IN COMMAND DEL PRODUCT VARIANT⚠️*", {
            parse_mode: "Markdown",
        })
        console.log(clc.red.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Something error in file command/privateCommand/delProduct.js :  ${err.message}`));
    }
}

module.exports = delProductVariant