const productsVariantModels = require("../../database/models/productsVariantModels");

const setHarga = async (ctx) => {
    try {

        if (process.env.WHITELIST_ID != ctx.from.id) {
            return
        }

        const input = ctx.message.text.split(" ");

        if (input.length <= 2) {
            return ctx.reply("Harap masukkan input dengan benar tidak boleh ada yang tertinggal.")
        }

        const price = parseInt(input[1])
        if (isNaN(price)) {
            return ctx.reply("Harap masukkan harga dengan benar dan hanya angka!!")
        }

        const checkCode = await productsVariantModels.findOne({ codeVariant: input[2] });

        if (!checkCode) {
            return ctx.reply("404 NOT FOUND || VARIANT TIDAK DI TEMUKAN")
        }

        await productsVariantModels.updateOne({ codeVariant: input[2] }, { $set: { price: price } })
        .then(() => {
            ctx.reply("*✅BERHASIL MELAKUKAN SET HARGA ✅*", {
                parse_mode: "Markdown",
            })
        }).catch(() => {
            ctx.reply("*⚠️SOMETHING ERROR IN UPDATE PRICE⚠️*", {
                parse_mode: "Markdown",
            })
        });

    } catch (err) {
        ctx.reply("*⚠️SOMETHING ERROR IN COMMAND SET HARGA⚠️*", {
            parse_mode: "Markdown",
        })
        console.log(clc.red.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Something error in file command/privateCommand/setHarga.js  ${err.message}`));
    }
}

module.exports = setHarga