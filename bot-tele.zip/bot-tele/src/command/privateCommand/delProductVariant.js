const clc = require('cli-color');
const moment = require('moment-timezone');
const productsModels = require('../../database/models/productsModels');
const productsVariantModels = require('../../database/models/productsVariantModels');

const delProduct = async (ctx) => {
    try {

        if (ctx.from.id != process.env.WHITELIST_ID) {
            return
        }

        const code = ctx.message.text.split(" ")
        const cekProduk = await productsModels.findOne({ code: code[1] })

        if (!cekProduk) {
            await ctx.reply("*❗Code yang kamu masukkan tidak di temukan*", {
                parse_mode: "Markdown"
            });
            return
        }

        await productsVariantModels.deleteMany({ code: parseInt(code[1]) })

        await productsModels.deleteOne({ code: code[1] })

        const remainingProducts = await productsModels.find().sort({ code: 1 });

        for (let i = 0; i < remainingProducts.length; i++) {
            const newCode = i + 1;

            await productsModels.findByIdAndUpdate(remainingProducts[i]._id, { code: newCode });

            await productsVariantModels.updateMany({ code: remainingProducts[i].code }, { code: newCode });
        }

        await ctx.reply("✅Berhasil menghapus product")
    } catch (err) {
        ctx.reply("*⚠️SOMETHING ERROR IN COMMAND DEL PRODUCT⚠️*", {
            parse_mode: "Markdown",
        })
        console.log(clc.red.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Something error in file command/privateCommand/delProductVariant.js :  ${err.message}`));
    }
}

module.exports = delProduct