const clc = require('cli-color');
const moment = require('moment-timezone')

const adminPanelCommand = async (ctx) => {
    try {
        if (process.env.WHITELIST_ID != ctx.from.id) {
            return
        }

        const text = `
*[ ADMIN HELP ]*

LIST COMMAND BANTUAN :
/caraaddproduct
/caradelproduct
/caraaddvariant
/caradelvariant
/caraaddstock
/caradelstock
/carasetharga
/carabroadcast

*Untuk melihat code variant klik tombol di bawah👇*`

        ctx.reply(text, {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '📃Show Code', callback_data: 'show-code-variant' },
                    ]
                ]
            },
            parse_mode: "Markdown"
        })
    } catch (err) {
        ctx.reply("*⚠️SOMETHING ERROR IN COMMAND ADMIN PANEL⚠️*", {
            parse_mode: "Markdown",
        })
        console.log(clc.red.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Something error in file command/privateCommand/adminPanel.js :  ${err.message}`));
    }
}

module.exports = adminPanelCommand