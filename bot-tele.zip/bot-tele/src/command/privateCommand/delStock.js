const moment = require('moment-timezone');
const clc = require('cli-color');
const productsVariantModels = require('../../database/models/productsVariantModels');
const stockModels = require('../../database/models/stockModels');

const delStock = async (ctx) => {
    try {
        const idTelegram = ctx.from.id;
        if (process.env.WHITELIST_ID == idTelegram) {
            const input = ctx.message.text.split(" ");
            const textReply = ctx.message?.reply_to_message?.text ?? "";
            const checkCode = await productsVariantModels.findOne({ codeVariant: input[1] });

            if (!checkCode) {
                return ctx.reply("*⚠️ CODE VARIANT PRODUCT TIDAK DI TEMUKAN ⚠️*", {
                    parse_mode: "Markdown"
                });
            } else if (textReply === "") {
                return ctx.reply("*⚠️ HARAP REPLY TEXT STOCK NYA AGAR BISA DI TAMBAHKAN ⚠️*", {
                    parse_mode: "Markdown"
                });
            }

            const stocks = textReply
                .split("\n")
                .map(product => product.trim())
                .filter(product => product);

            let i = 0;
            for (const stock of stocks) {
                await stockModels.deleteOne({ dataStock: stock });
                i++;
            }

            ctx.reply(`*✅ BERHASIL MENGHAPUS STOCK | TOTAL STOCK YANG DI HAPUS : ${i} ✅*`, {
                parse_mode: "Markdown"
            });

        }
    } catch (err) {
        ctx.reply("*⚠️SOMETHING ERROR IN COMMAND DELSTOCK⚠️*", {
            parse_mode: "Markdown",
        });
        console.log(clc.red.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Something error in file command/privateCommand/delStock.js  ${err.message}`));
    }
};

module.exports = delStock;