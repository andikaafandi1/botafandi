const mongoose = require('mongoose');
const clc = require("cli-color");
const moment = require('moment-timezone');

const db = mongoose.connection;

async function connectDatabase() {
    try {
        await mongoose.connect(process.env.DATABASE_MONGODB_URI, {
            dbName: "DapiBOT"
        });
    } catch (error) {
        console.clear()
        console.log("MongoDB connection error:", error);
        process.exit()

    }
}

db.once("connected", () => {
    console.log(clc.green.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(" Success connect to database"));
});

module.exports = connectDatabase;