const fs = require('fs').promises;
const productsVariantModels = require("../database/models/productsVariantModels");
const stockModels = require("../database/models/stockModels");
const transactionModels = require("../database/models/transactionModels");
const clc = require('cli-color');
const moment = require('moment-timezone');
const addStocks = require("../utils/addStocks");
const createQRIS = require("../utils/createQRIS");

function generateRandomCode() {
    const prefix = "INV";

    const date = new Date();
    const year = date.getFullYear().toString().slice(-2);
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const datePart = `${year}${month}${day}`;

    const randomNumber = Math.floor(1000 + Math.random() * 9000);

    const randomCode = `${prefix}${datePart}${randomNumber}`;
    return randomCode;
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

async function generateUniqueRandomPrice() {
    const totalPriceList = [];
    const getTransaction = await transactionModels.find({ isSuccess: false, isCanceled: false });

    getTransaction.forEach(data => {
        const createdAt = moment(data.createdAt);
        const time = moment();
        const selisih = time.diff(createdAt, 'minutes');

        if (selisih < 6) {
            totalPriceList.push(data.feeTax);
        }
    });

    let randomPrice;
    let feeExists = true;

    while (feeExists) {
        randomPrice = getRandomInt(0, 155);

        feeExists = totalPriceList.includes(randomPrice);

        if (feeExists) {
            console.log(clc.blue.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Fee ${randomPrice} sudah ada, mencari fee baru...`));
        }
    }

    totalPriceList.push(randomPrice);

    return randomPrice.toString().padStart(2, '0');
}

class HandleAction {
    async ShowPesanan(ctx) {
        try {
            const variantValue = ctx.match[1]
            const SearchCodeVariant = await productsVariantModels.findOne({ codeVariant: variantValue });

            if (!SearchCodeVariant) {
                return ctx.answerCbQuery("404 PRODUCTS NOT FOUND", { show_alert: true });
            }
            const allStock = await stockModels.find({ codeVariant: variantValue })

            if (allStock.length == 0) {
                return ctx.answerCbQuery("SISA STOCK 0 TIDAK BISA MELANJUTKAN..", { show_alert: true });
            }
            await delay(1_000)
            if (ctx.callbackQuery && ctx.callbackQuery.message) {
                const messageId = ctx.callbackQuery.message.message_id;

               await ctx.deleteMessage(messageId)
            }

            let data = "*KONFIRMASI PESANAN*\n"
            data += "*╭─────────────────╮*\n"
            data += `*│ Product:* ${SearchCodeVariant.name.toUpperCase()}\n`
            data += `*│ Code Variant:* ${SearchCodeVariant.codeVariant}\n`
            data += `*│ Harga:* Rp ${SearchCodeVariant.price.toLocaleString('id-ID')}\n`
            data += `*│ Stock Tersedia:* ${allStock.length}\n`
            data += "*│──────────────────*\n"
            data += `*│ Jumlah Pesanan:* 1\n`
            const totalPrice = 1 * SearchCodeVariant.price
            data += `*│ Total dibayar:* Rp ${parseInt(totalPrice).toLocaleString('id-ID')}\n`
            data += "*╰─────────────────╯*\n"
            data += "*╰➤ Jika ingin mengorder klik Confirm Order✅*"

            return ctx.reply(data, {
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '-', callback_data: 'mines-order' },
                            { text: '+', callback_data: 'plus-order' },
                        ],
                        [
                            { text: '🔙Kembali', callback_data: "back-to-product-list" },
                            { text: 'Confirm Order✅', callback_data: 'confirm-order' },
                        ]
                    ]
                },
                parse_mode: "Markdown"
            })
        } catch (err) {
            console.error(`[ ERROR ] [${moment().format('YYYY-MM-DD HH:mm:ss')}]:`, {
                userId: ctx.from?.id,
                action: ctx.callbackQuery?.data,
                error: err.message,
                stack: err.stack,
            });
            ctx.reply(`*⚠️ ERROR:* ${err.message}\nSilakan coba lagi atau hubungi admin jika masalah berlanjut.`, {
                parse_mode: "Markdown",
            });
        }
    }

    async PlusMinesStockProduct(ctx) {
        try {
            const action = ctx.callbackQuery.data;

            const messageText = ctx.callbackQuery.message.text;
            const orderAmountMatch = messageText.match(/Jumlah Pesanan:\s*(\d+)/);
            const productMatch = messageText.match(/Product:\s*(.+)/);
            const codeVariantMatch = messageText.match(/Code Variant:\s*(.+)/);
            const priceMatch = messageText.match(/Harga:\s*Rp\s*([\d,.]+)/);
            const stockMatch = messageText.match(/Stock Tersedia:\s*(\d+)/);

            let orderAmount = orderAmountMatch ? parseInt(orderAmountMatch[1]) : null;
            const product = productMatch ? productMatch[1].trim() : null;
            const codeVariant = codeVariantMatch ? codeVariantMatch[1].trim() : null;
            const price = priceMatch ? priceMatch[1].replace(/\./g, '').trim() : null;
            const stock = stockMatch ? parseInt(stockMatch[1]) : null;

            if (!ctx.session) {
                ctx.session = {};
            }

            const userLastAction = ctx.session?.lastAction || 0;
            const currentTime = Date.now();

            const minimumDelay = 1_500;

            if (currentTime - userLastAction < minimumDelay) {
                return ctx.answerCbQuery("Tunggu sebentar sebelum memencet tombol lagi!", { show_alert: true });
            }

            ctx.session.lastAction = currentTime;

            ctx.session.lastAction = currentTime;

            if (action == 'mines-order' && orderAmount == 1) {
                return ctx.answerCbQuery("Jumlah orderan tidak boleh 0 atau mines!!", { show_alert: true });
            }

            if (action == 'plus-order') {
                orderAmount++;
            } else if (action == 'mines-order') {
                orderAmount--;
            }

            if (orderAmount > stock) {
                return ctx.answerCbQuery("Stock tidak cukup", { show_alert: true });
            }

            const totalPrice = orderAmount * parseInt(price);
            let data = "*KONFIRMASI PESANAN*\n";
            data += "*╭─────────────────╮*\n";
            data += `*│ Product:* ${product.toUpperCase()}\n`;
            data += `*│ Code Variant:* ${codeVariant}\n`;
            data += `*│ Harga:* Rp ${parseInt(price).toLocaleString('id-ID')}\n`;
            data += `*│ Stock Tersedia:* ${stock}\n`;
            data += "*│──────────────────*\n";
            data += `*│ Jumlah Pesanan:* ${orderAmount}\n`;
            data += `*│ Total dibayar:* Rp ${parseInt(totalPrice).toLocaleString('id-ID')}\n`;
            data += "*╰─────────────────╯*\n";
            data += "*╰➤ Jika ingin mengorder klik Confirm Pesanan✅*";

            await ctx.editMessageText(data, {
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '-', callback_data: 'mines-order' },
                            { text: '+', callback_data: 'plus-order' },
                        ],
                        [
                            { text: '🔙Kembali', callback_data: 'back-to-product-list' },
                            { text: 'Confirm Order✅', callback_data: 'confirm-order' },
                        ]
                    ]
                },
                parse_mode: 'Markdown'
            });

            ctx.answerCbQuery();
        } catch (err) {
            console.error(`[ ERROR ] [${moment().format('YYYY-MM-DD HH:mm:ss')}]:`, {
                userId: ctx.from?.id,
                action: ctx.callbackQuery?.data,
                error: err.message,
                stack: err.stack,
            });
            ctx.reply(`*⚠️ ERROR:* ${err.message}\nSilakan coba lagi atau hubungi admin jika masalah berlanjut.`, {
                parse_mode: "Markdown",
            });
        }
    }


    async ConfirmOrder(ctx) {
        try {
            await delay(1_000)
            if (ctx.callbackQuery && ctx.callbackQuery.message) {
                const messageId = ctx.callbackQuery.message.message_id;

               await ctx.deleteMessage(messageId)
            }
            const messageText = ctx.callbackQuery.message.text;
            const orderAmountMatch = messageText.match(/Jumlah Pesanan:\s*(\d+)/);
            const productMatch = messageText.match(/Product:\s*(.+)/);
            const codeVariantMatch = messageText.match(/Code Variant:\s*(.+)/);
            const priceMatch = messageText.match(/Harga:\s*Rp\s*([\d,.]+)/);

            let orderAmount = orderAmountMatch ? parseInt(orderAmountMatch[1]) : null;
            const product = productMatch ? productMatch[1] : null;
            const codeVariant = codeVariantMatch ? codeVariantMatch[1] : null;
            const price = priceMatch ? priceMatch[1].replace(/\./g, '').trim() : null;

            const getVariantProduct = await productsVariantModels.findOne({ codeVariant: codeVariant });
            const getTransaction = await transactionModels.findOne({ telegramUserId: ctx.from.id, isSuccess: false, isCanceled: false });

            if (getTransaction) {
                return ctx.answerCbQuery("Tidak bisa confirm order, Harap selesaikan transaction sebelumnya", { show_alert: true });
            }

            const UserID = ctx.from.id;

            if (!getVariantProduct) {
                await ctx.editMessageText("*⚠️ Tidak bisa mendapatkan product, Harap coba lagi nanti*", {
                    parse_mode: 'Markdown',
                });

                ctx.answerCbQuery();
                return;
            }
            ctx.answerCbQuery("Bot sedang membuat QRIS..", { show_alert: true });
            const fee = await generateUniqueRandomPrice()
            const totalAmount = Number(orderAmount * price) + Number(fee);

            const formattedDateFile = moment().tz('Asia/Jakarta').format('YYYY-MM-DD_HH-mm-ss');

            const uniqCode = generateRandomCode()

            await createQRIS(`${totalAmount}`, `./src/img/qris/qris-${formattedDateFile}.png`)

            await delay(3000)

            let expirationTime = new Date(Date.now() + 5 * 60 * 1000);
            let formattedTime = new Date(expirationTime).toLocaleTimeString("en-US", { timeZone: "Asia/Jakarta", hour12: false }).slice(0, 5);

            let text = "*╭──────────────\n*";
            text += `*│ Produk:* ${product.toUpperCase()}\n`;
            text += `*│ Harga satuan:* Rp ${parseInt(price).toLocaleString('id-ID')}\n`;
            text += `*│ ID TRX :* ${uniqCode}\n`;
            text += "*│─────────────── *\n";
            text += `*│ Jumlah Pesanan:* ${orderAmount}\n`;
            text += `*│ Total yang di bayar:* Rp ${totalAmount.toLocaleString('id-ID')}\n`;
            text += "*╰─────────────\n*";
            text += `*Harap selesaikan pembayaran sebelum jam ${formattedTime} WIB⏲️ dengan cara scan QRIS di atas*\n\nIngin membatalkan transaksi? Klik button *Cancel Order❌*`;

            const sendMessage = await ctx.telegram.sendPhoto(UserID, { source: `./src/img/qris/qris-${formattedDateFile}.png` }, {
                caption: text,
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "Cancel Order❌", callback_data: "cancel-order-pesanan" }],
                    ],
                },
                parse_mode: "Markdown",
            });
            await fs.unlink(`./src/img/qris/qris-${formattedDateFile}.png`)

            const ProductVariant = await productsVariantModels.findOne({ codeVariant: codeVariant });
            const getStock = await stockModels.find({ codeVariant: ProductVariant.codeVariant });

            let dataStock = "";
            let totalStock = 0;
            for (const stock of getStock) {
                if (totalStock >= orderAmount) {
                    break;
                }

                dataStock += `${stock.dataStock}\n`;
                await stockModels.deleteOne({ dataStock: stock.dataStock });
                totalStock++;
            }

            const formattedDate = moment().tz('Asia/Jakarta').format('YYYY-MM-DD HH:mm:ss');

            const NewTransaction = new transactionModels({
                transactionId: uniqCode,
                telegramUserId: UserID,
                productCode: ProductVariant.codeVariant,
                orderQuantity: orderAmount,
                formattedDate: formattedDate,
                feeTax: fee,
                totalPrice: totalAmount,
                orderData: dataStock,
                chatId: sendMessage.chat.id,
                keteranganVariant: ProductVariant.keteranganVariant,
                messageId: sendMessage.message_id,
            });

            await NewTransaction.save();
            ctx.answerCbQuery();
        } catch (err) {
            console.error(`[ ERROR ] [${moment().format('YYYY-MM-DD HH:mm:ss')}]:`, {
                userId: ctx.from?.id,
                action: ctx.callbackQuery?.data,
                error: err.message,
                stack: err.stack,
            });
            ctx.reply(`*⚠️ ERROR:* ${err.message}\nSilakan coba lagi atau hubungi admin jika masalah berlanjut.`, {
                parse_mode: "Markdown",
            });
        }
    }

    async cancelOrder(ctx) {
        try {
            await delay(1_000)
            if (ctx.callbackQuery && ctx.callbackQuery.message) {
                const messageId = ctx.callbackQuery.message.message_id;

               await ctx.deleteMessage(messageId)
            }

            const getTransaction = await transactionModels.findOne({ telegramUserId: ctx.from.id, isCanceled: false, isSuccess: false });

            await addStocks(getTransaction.orderData, getTransaction.productCode)
            await transactionModels.updateOne({ telegramUserId: ctx.from.id, isCanceled: false, isSuccess: false }, { $set: { isCanceled: true } })
            ctx.reply("*✅ Berhasil membatalkan transaction yang sedang kamu lakukan*", {
                parse_mode: "Markdown"
            })
            ctx.answerCbQuery();
        } catch (err) {
            console.error(`[ ERROR ] [${moment().format('YYYY-MM-DD HH:mm:ss')}]:`, {
                userId: ctx.from?.id,
                action: ctx.callbackQuery?.data,
                error: err.message,
                stack: err.stack,
            });
            ctx.reply(`*⚠️ ERROR:* ${err.message}\nSilakan coba lagi atau hubungi admin jika masalah berlanjut.`, {
                parse_mode: "Markdown",
            });
        }
    }

    async showAllproductVariant(ctx) {
        try {
            let text = "*[ SHOW CODE PRODUCT VARIANT ]*\n\n"
            const getAllData = await productsVariantModels.find()

            for (const variant of getAllData) {
                text += `\`${variant.name.toUpperCase()} || ${variant.codeVariant}\`\n`
            }

            ctx.reply(text, {
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🔙 Back', callback_data: 'back-to-adminmenu' },
                        ]
                    ]
                },
                parse_mode: "Markdown"
            })
        } catch (err) {
            console.error(`[ ERROR ] [${moment().format('YYYY-MM-DD HH:mm:ss')}]:`, {
                userId: ctx.from?.id,
                action: ctx.callbackQuery?.data,
                error: err.message,
                stack: err.stack,
            });
            ctx.reply(`*⚠️ ERROR:* ${err.message}\nSilakan coba lagi atau hubungi admin jika masalah berlanjut.`, {
                parse_mode: "Markdown",
            });
        }
    }

}

module.exports = HandleAction