const productsVariantModels = require("../database/models/productsVariantModels")
const stockModels = require("../database/models/stockModels")
const transactionModels = require("../database/models/transactionModels")
const productsModels = require("../database/models/productsModels")

class HandleHears {

    async handleProductList(ctx) {
        try {
            const message = ctx.message.text
            const numberRegex =  /^\d+$/;

            if (numberRegex.test(message)) {
                const codeNumber = message
                const getAllProductVariant = await productsVariantModels.find({ code: codeNumber });

                const getProduct = await productsModels.findOne({ code: codeNumber });

                if (!getProduct) return

                if (getAllProductVariant.length == 0) {
                    return ctx.reply(
                        "*⚠️ VARIANT PRODUCTS BELUM ADA ⚠️*",
                        {
                            reply_markup: {
                                inline_keyboard: [
                                    [
                                        { text: '🔙 Back', callback_data: 'back-to-listproduct' },
                                    ]
                                ]
                            },
                            parse_mode: 'Markdown'
                        }
                    );
                }

                const stockTersedia = async (code) => {
                    const totalStock = await stockModels.find({ codeVariant: code })

                    return totalStock.length
                }

                const stockTerjual = async (code) => {
                    const totalTerjual = await transactionModels.find({ productCode: code, isSuccess: true, isCanceled: false })

                    return totalTerjual.length
                }

                function addButton(inlineKeyboard, text, callbackData) {
                    const newButton = { text: text, callback_data: callbackData };

                    if (inlineKeyboard.length === 0 || inlineKeyboard[inlineKeyboard.length - 1].length >= 2) {
                        inlineKeyboard.push([newButton]);
                    } else {
                        inlineKeyboard[inlineKeyboard.length - 1].push(newButton);
                    }

                    return inlineKeyboard;
                }

                let text = ""
                let inlineKeyboard = []
                for (const data of getAllProductVariant) {
                    if (getAllProductVariant.length == 1) {
                        text += `*╭───── 〔 ${data.name} 〕 ──*\n`
                        text += `*┊・ Harga:* Rp ${data.price.toLocaleString('id-ID')}\n`
                        text += `*┊・ Stock Tersedia:* ${await stockTersedia(data.codeVariant)}\n`
                        text += `*┊・ Stock Terjual:* ${await stockTerjual(data.codeVariant)}\n`
                        text += `*┊・ Deskripsi:* ${data.descriptionVariant}`
                        text += "\n*╰───────────────*"
                    } else {
                        text += `*╭───── 〔 ${data.name} 〕 ──*\n`
                        text += `*┊・ Harga:* Rp ${data.price.toLocaleString('id-ID')}\n`
                        text += `*┊・ Stock Tersedia:* ${await stockTersedia(data.codeVariant)}\n`
                        text += `*┊・ Stock Terjual:* ${await stockTerjual(data.codeVariant)}\n`
                        text += `*┊・ Deskripsi:* ${data.descriptionVariant}`
                        text += "\n*╰───────────────*\n\n"
                    }

                    inlineKeyboard = addButton(inlineKeyboard, `${data.name}📦`, `variant-${data.codeVariant.toLowerCase()}`);
                }

                if (getAllProductVariant.length == 1) {
                    text += "\n╰➤ If want to order click the button below"
                } else {
                    text += "╰➤ If want to order click the button below"
                }
                inlineKeyboard.push([{ text: "🔙Back", callback_data: "back-to-product-list" }])

                await ctx.reply(text, {
                    reply_markup: {
                        inline_keyboard: inlineKeyboard
                    },
                    parse_mode: "Markdown"
                })
            }
        } catch (err) {
            ctx.reply("*⚠️SOMETHING ERROR IN HANDLE ACTION⚠️*", {
                parse_mode: "Markdown",
            })
            console.log(clc.red.bold("[ INFO ]") + ` [${moment().format('HH:mm:ss')}]:` + clc.blueBright(` Something error in file handler/HandleAction :  ${err.message}`));
        }
    }

    async GetTopBuyer(ctx) {
        try {
            const topBuyers = await transactionModels.aggregate([
                { $match: { isSuccess: true } },
                {
                    $group: {
                        _id: "$telegramUserId",
                        totalSpent: { $sum: "$totalPrice" },
                        totalOrders: { $sum: 1 } 
                    }
                },
                { $sort: { totalSpent: -1 } },
                { $limit: 5 }
            ]);

            let buyerMessage = "*🎉 Top 5 Buyers 🎉*\n";
            buyerMessage += "🔥 Berikut adalah pelanggan paling loyal dengan total belanja tertinggi: 🔥\n";
            topBuyers.forEach((buyer, index) => {
                buyerMessage += `\n${index + 1}. 🏆 *User ID:* \`${buyer._id}\`\n   💰 *Total Belanja:* Rp${buyer.totalSpent.toLocaleString('id-ID')}\n   📦 *Total Pesanan:* ${buyer.totalOrders} transaksi\n`;
            });

            await ctx.reply(`${buyerMessage}`, { parse_mode: "Markdown" });
        } catch (error) {
            console.error("Error fetching top buyers or products:", error);
            await ctx.reply("*⚠️ Terjadi kesalahan saat mengambil data Top Buyers dan Top Products ⚠️*", { parse_mode: "Markdown" });
        }
    }

    async GetTopProduct(ctx) {
        try {

            const topProducts = await transactionModels.aggregate([
                { $match: { isSuccess: true } },
                {
                    $group: {
                        _id: "$productCode",
                        totalSold: { $sum: "$orderQuantity" },
                        revenue: { $sum: "$totalPrice" }
                    }
                },
                { $sort: { totalSold: -1 } },
                { $limit: 10 }
            ]);

            let productMessage = "\n*📦 Top 10 Products 📦*\n";
            productMessage += "✨ Produk-produk yang paling laris di toko kami: ✨\n";
            topProducts.forEach((product, index) => {
                productMessage += `\n${index + 1}. 🔖 *Kode Produk:* \`${product._id}\`\n   🔢 *Jumlah Terjual:* ${product.totalSold}\n   💵 *Pendapatan:* Rp${product.revenue.toLocaleString('id-ID')}\n`;
            });

            await ctx.reply(`${productMessage}`, { parse_mode: "Markdown" });
        } catch (error) {
            console.error("Error fetching top buyers or products:", error);
            await ctx.reply("*⚠️ Terjadi kesalahan saat mengambil data Top Buyers dan Top Products ⚠️*", { parse_mode: "Markdown" });
        }
    }

}

module.exports = HandleHears